function createBoard() {
  let text = "";
  let col = 6;
  let row = 5;
  let c = 30;
  text += "<table>";
  for (y = 0; y < row; y++) {
    text += "<tr>";
    for (x = 0; x < col; x++) {
      text += "<td id='boardIndex-" + c + "' bgcolor='#b0b3b8'>" + c + "</td>";
      y % 2 ? c++ : c--;
    }
    c = y % 2 ? c - 7 : c - 5;
    text += "</tr>";
  }
  text += "</table>";
  document.getElementById("board").innerHTML = text;
}

function createDice() {
  let text = "";
  let index = 1;
  text += "<div class='dice'>";
  text += "<ol class='die-list even-roll' data-roll='1' id='die-1'>";
  for (i = 0; i < 6; i++) {
    text += "<li class='die-item' data-side='" + index + "'>";
    for (x = 0; x < index; x++) {
      text += "<span class='dot'></span>";
    }
    text += "</li>";
    index++;
  }
  text +=
    "</ol>" +
    "</div>" +
    "<br>" +
    "<div align='center'>" +
    "    <button type='button' id='roll-button'>Roll Dice</button>" +
    "</div>";
  document.getElementById("dicetr").innerHTML = text;
}

function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&amp;amp;]" + name + "=([^&amp;amp;#]*)"),
    results = regex.exec(location.search);
  return results === null
    ? ""
    : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function insertImagePlayer1(character) {
  let imgPlayer1 = "<img src='icons/icon-" + character + ".svg'>";
  document.getElementById("player1").innerHTML = imgPlayer1;
}
function insertImagePlayer2(character) {
  let imgPlayer2 = "<img src='icons/icon-" + character + ".svg'>";
  document.getElementById("player2").innerHTML = imgPlayer2;
}
function insertImageWinner(character) {
  let imgWinner =
    "<img src='icons/icon-" + character + ".svg' width='400' height='400'>";
  document.getElementById("winner").innerHTML = imgWinner;
}


