var aux=0;
function rollDice() {
  document.getElementById("roll-button").disabled=true;
  const dice = [...document.querySelectorAll(".die-list")];
  dice.forEach(die => {
    toggleClasses(die);
    die.dataset.roll = getRandomNumber(1, 6);
    
    setTimeout(function() {
      createPosition(turn==1?posOld1:posOld2, parseInt(die.dataset.roll), turn);
    }, 2000)
   sleep(3000).then(()=>{getJson(aux, turn);});
   sleep(4500).then(()=>{changeTurn();});

  });
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function toggleClasses(die) {
  die.classList.toggle("odd-roll");
  die.classList.toggle("even-roll");
}

function getRandomNumber(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

document.getElementById("roll-button").addEventListener("click", rollDice);



function createPosition(posOld, posNew, turn) {
  let element =
    turn == 1
      ? document.getElementById("img-p1")
      : document.getElementById("img-p2");
  aux = posOld + posNew;

  let conOld = document.getElementById("boardIndex-" + posOld);
  if (conOld) conOld.removeChild(element);

  if (aux < 30) {
    let conNew = document.getElementById("boardIndex-" + aux);
    conNew.appendChild(element);

    // getJson(aux, turn);

    if (turn == 1) posOld1 += posNew;
    else posOld2 += posNew;

  }

  if (aux >= 30) {
    let imageId;
    if (turn == 1) imageId = getParameterByName("player1");
    else imageId = getParameterByName("player2");

    window.location.replace("finish.html?winner=" + imageId);
  } 
}

function changeTurn() {
  if (turn == 1) {
    
    let elementP1 = document.getElementById("player1");
    let elementP2 = document.getElementById("player2");
    elementP2.classList.add("player2");
    elementP1.classList.remove("player1");
    turn = 2;
  } else {
    
    let elementP1 = document.getElementById("player1");
    let elementP2 = document.getElementById("player2");
    elementP1.classList.add("player1");
    elementP2.classList.remove("player2");
    turn = 1;
  }
  sleep(1000).then(()=>{document.getElementById("msg").innerHTML = '';}).then(()=>{
    document.getElementById("roll-button").disabled=false;
  
  }); 

}

function getParameterByName(name) {
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  var regex = new RegExp("[\\?&amp;amp;]" + name + "=([^&amp;amp;#]*)"),
    results = regex.exec(location.search);
  return results === null
    ? ""
    : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function getJson(aux, turn) {
  var data2 = JSON.parse(got);
  for (let index = 0; index < data2.length; index++) {
    let element = data2[index];
    if (element["Id"] == aux) {
      let val = parseInt(element["Value"]);
      let message = element["Message"];

      let timeout = 2;
      if (message && message.lenth > 0) {
        console.log(message);
        timeout = 6;
      }

      document.getElementById("msg").innerHTML = message;
      
      setTimeout(function(){createPosition(aux, val, turn);}, timeout * 1000); 

      break;
    }
  }
}
